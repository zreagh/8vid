#' ---
#' title: Analyze 8vid behavioral data
#' author: Zachariah M. Reagh
#' output:
#'  html_document:
#'    toc: true
#'    toc_depth: 5
#'    toc_float:
#'      collapsed: false
#'      smooth_scroll: false
#'    number_sections: true
#'    theme: spacelab
#' ---

### Setup paths
SUBJECTS_DIR <- "/Users/zreagh/Desktop/8vid_logs_csv/"
ANALYSIS_DIR <- "/Users/zreagh/Desktop/8vid_logs_csv/analyzed/"
FIGS_DIR <- "/Users/zreagh/Desktop/8vid_logs_csv/figs/"

### Figure out subjects
subj_files <- c(list.files(path=SUBJECTS_DIR, pattern="recognition"))
subjects <- substr(subj_files,1,3)
print(subjects)
length(subjects)

### Set up blank variables for group data
total_rec_score <- vector()
tommy_rec_score <- vector()
lisa_rec_score <- vector()
delta_rec_score <- vector()
mishkas_rec_score <- vector()
nugget_rec_score <- vector()
coop_rec_score <- vector()
tommy_delta_rec_score <- vector()
tommy_mishkas_rec_score <- vector()
tommy_nugget_rec_score <- vector()
tommy_coop_rec_score <- vector()
lisa_delta_rec_score <- vector()
lisa_mishkas_rec_score <- vector()
lisa_nugget_rec_score <- vector()
lisa_coop_rec_score <- vector()
all_subj <- NULL
all_subj <- data.frame(subjects)

### Load in the data and calculate recognition performance
for(isubj in subj_files){
  cat(sprintf("\nWorking on %s\n", isubj))
  subj_data <- data.frame(read.csv(isubj, header=TRUE, sep=",", skip=5))
  # Calculate the overall recognition score
  total_rec_score[isubj] = mean(1*(subj_data$Correct==subj_data$Keypress))
  # Calculate recognition for videos featuring Tommy
  filt_score <- grepl("Tommy",subj_data$Scene)
  tommy_rec_score[isubj] = mean(1*(subj_data$Correct[filt_score]==subj_data$Keypress[filt_score]))
  # Calculate recognition for videos featuring Lisa
  filt_score <- grepl("Lisa",subj_data$Scene)
  lisa_rec_score[isubj] = mean(1*(subj_data$Correct[filt_score]==subj_data$Keypress[filt_score]))
  # Calculate recognition for videos in Delta of Venus
  filt_score <- grepl("Delta",subj_data$Scene)
  delta_rec_score[isubj] = mean(1*(subj_data$Correct[filt_score]==subj_data$Keypress[filt_score]))
  # Calculate recognition for videos in Mishka's
  filt_score <- grepl("Mishkas",subj_data$Scene)
  mishkas_rec_score[isubj] = mean(1*(subj_data$Correct[filt_score]==subj_data$Keypress[filt_score]))
  # Calculate recognition for videos in Nugget Market
  filt_score <- grepl("Nugget",subj_data$Scene)
  nugget_rec_score[isubj] = mean(1*(subj_data$Correct[filt_score]==subj_data$Keypress[filt_score]))
  # Calculate recognition for videos in Food Co-Op
  filt_score <- grepl("Co-Op",subj_data$Scene)
  coop_rec_score[isubj] = mean(1*(subj_data$Correct[filt_score]==subj_data$Keypress[filt_score]))
  # Calculate recognition for Tommy videos in Delta of Venus
  filt_score <- grepl("TommyDelta",subj_data$Scene)
  tommy_delta_rec_score[isubj] = mean(1*(subj_data$Correct[filt_score]==subj_data$Keypress[filt_score]))
  # Calculate recognition for videos in Mishka's
  filt_score <- grepl("TommyMishkas",subj_data$Scene)
  tommy_mishkas_rec_score[isubj] = mean(1*(subj_data$Correct[filt_score]==subj_data$Keypress[filt_score]))
  # Calculate recognition for videos in Nugget Market
  filt_score <- grepl("TommyNugget",subj_data$Scene)
  tommy_nugget_rec_score[isubj] = mean(1*(subj_data$Correct[filt_score]==subj_data$Keypress[filt_score]))
  # Calculate recognition for videos in Food Co-Op
  filt_score <- grepl("TommyCoOp",subj_data$Scene)
  tommy_coop_rec_score[isubj] = mean(1*(subj_data$Correct[filt_score]==subj_data$Keypress[filt_score]))
  # Calculate recognition for Lisa videos in Delta of Venus
  filt_score <- grepl("LisaDelta",subj_data$Scene)
  lisa_delta_rec_score[isubj] = mean(1*(subj_data$Correct[filt_score]==subj_data$Keypress[filt_score]))
  # Calculate recognition for videos in Mishka's
  filt_score <- grepl("LisaMishkas",subj_data$Scene)
  lisa_mishkas_rec_score[isubj] = mean(1*(subj_data$Correct[filt_score]==subj_data$Keypress[filt_score]))
  # Calculate recognition for videos in Nugget Market
  filt_score <- grepl("LisaNugget",subj_data$Scene)
  lisa_nugget_rec_score[isubj] = mean(1*(subj_data$Correct[filt_score]==subj_data$Keypress[filt_score]))
  # Calculate recognition for videos in Food Co-Op
  filt_score <- grepl("LisaCoOp",subj_data$Scene)
  lisa_coop_rec_score[isubj] = mean(1*(subj_data$Correct[filt_score]==subj_data$Keypress[filt_score]))
  cat(sprintf("Done!\n", isubj))
}

### Aggregate our performance variables into the all_subj data frame (can I loop this?)
all_subj$total_rec <- total_rec_score
all_subj$tommy_rec <- tommy_rec_score
all_subj$lisa_rec <- lisa_rec_score
all_subj$delta_rec <- delta_rec_score
all_subj$mishkas_rec <- mishkas_rec_score
all_subj$nugget_rec <- nugget_rec_score
all_subj$coop_rec <- coop_rec_score
all_subj$tommy_delta_rec <- tommy_delta_rec_score
all_subj$tommy_mishkas_rec <- tommy_mishkas_rec_score
all_subj$tommy_nugget_rec <- tommy_nugget_rec_score
all_subj$tommy_coop_rec <- tommy_coop_rec_score
all_subj$lisa_delta_rec <- lisa_delta_rec_score
all_subj$lisa_mishkas_rec <- lisa_mishkas_rec_score
all_subj$lisa_nugget_rec <- lisa_nugget_rec_score
all_subj$lisa_coop_rec <- lisa_coop_rec_score

### Set up another dataframe for running one-way ANOVAs (eventually rework to just start with this)
anova_df <- NULL
subj_vec <- c(rep(all_subj$subjects,8))
char_vec <- c(rep("Tommy",length(subjects)),rep("Lisa",length(subjects)),
              rep("Tommy",length(subjects)),rep("Lisa",length(subjects)),
              rep("Tommy",length(subjects)),rep("Lisa",length(subjects)),
              rep("Tommy",length(subjects)),rep("Lisa",length(subjects)))
loc_vec <- c(rep("Delta",length(subjects)*2),rep("Mishkas",length(subjects)*2),
             rep("Nugget",length(subjects)*2),rep("CoOp",length(subjects)*2))
score_vec <- c(all_subj$tommy_delta_rec,all_subj$lisa_delta_rec,all_subj$tommy_mishkas_rec,
               all_subj$lisa_mishkas_rec,all_subj$tommy_nugget_rec,all_subj$lisa_nugget_rec,
               all_subj$tommy_coop_rec,all_subj$lisa_coop_rec)
anova_df <- data.frame(subj_vec,char_vec,loc_vec,score_vec)
means_df <- colMeans(anova_df)

### Statistical testing
# One-sample t-tests comparing each recognition category to chance (50% accuracy)
total_rec_vs_chance <- t.test(all_subj$total_rec,mu=0.5)
tommy_rec_vs_chance <- t.test(all_subj$tommy_rec,mu=0.5)
lisa_rec_vs_chance <- t.test(all_subj$lisa_rec,mu=0.5)
delta_rec_vs_chance <- t.test(all_subj$delta_rec,mu=0.5)
mishkas_rec_vs_chance <- t.test(all_subj$mishkas_rec,mu=0.5)
nugget_rec_vs_chance <- t.test(all_subj$nugget_rec,mu=0.5)
coop_rec_vs_chance <- t.test(all_subj$coop_rec,mu=0.5)
tommy_delta_rec_vs_chance <- t.test(all_subj$tommy_delta_rec,mu=0.5)
tommy_mishkas_rec_vs_chance <- t.test(all_subj$tommy_mishkas_rec,mu=0.5)
tommy_nugget_rec_vs_chance <- t.test(all_subj$tommy_nugget_rec,mu=0.5)
tommy_coop_rec_vs_chance <- t.test(all_subj$tommy_coop_rec,mu=0.5)
lisa_delta_rec_vs_chance <- t.test(all_subj$lisa_delta_rec,mu=0.5)
lisa_mishkas_rec_vs_chance <- t.test(all_subj$lisa_mishkas_rec,mu=0.5)
lisa_nugget_rec_vs_chance <- t.test(all_subj$lisa_nugget_rec,mu=0.5)
lisa_coop_rec_vs_chance <- t.test(all_subj$lisa_coop_rec,mu=0.5)

# Paired t-test comparing overall Tommy and Lisa recognition scores
lisa_vs_tommy_rec <- t.test(all_subj$tommy_rec,all_subj$lisa_rec,paired=TRUE)

# One-way ANOVA comparing across multiple videos
contexts_rec <- aov(anova_df$score_vec ~ anova_df$loc_vec, data=anova_df)
char_rec <- aov(anova_df$score_vec ~ anova_df$char_vec, data=anova_df)

# Two-way ANOVA with character and context as factors
char_by_context_rec <- (aov(anova_df$score_vec ~ anova_df$char_vec * anova_df$loc_vec, data=anova_df))
posthoc <- TukeyHSD(char_by_context_rec)

### Write stats to a text file in the 'analyzed' directory
data <- capture.output(print(total_rec_vs_chance),print(tommy_rec_vs_chance),print(lisa_rec_vs_chance),
                       print(delta_rec_vs_chance),print(mishkas_rec_vs_chance),print(nugget_rec_vs_chance),
                       print(coop_rec_vs_chance),print(tommy_delta_rec_vs_chance),
                       print(tommy_mishkas_rec_vs_chance),print(tommy_nugget_rec_vs_chance),
                       print(tommy_coop_rec_vs_chance),print(lisa_delta_rec_vs_chance),
                       print(lisa_mishkas_rec_vs_chance),print(lisa_nugget_rec_vs_chance),
                       print(lisa_coop_rec_vs_chance),print(lisa_vs_tommy_rec),
                       print(summary(contexts_rec)),print(summary(char_rec)),
                       print(summary(char_by_context_rec)),print(posthoc))
writeLines(data,con=file.path(ANALYSIS_DIR,"stats.txt"))

# Create a figure and save it to the 'figs' directory
library(ggplot2)
fig <- ggplot(aes(y = anova_df$score_vec, x=anova_df$loc_vec, fill=anova_df$char_vec), data=anova_df, xlab="Location", ylab="Accuracy") + geom_boxplot()
fig + labs(x="Location",y="Accuracy") + scale_fill_discrete(name="Character")

dev.print(pdf, './figs/beh_plot.pdf')
